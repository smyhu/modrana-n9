"""a map tile Class"""
